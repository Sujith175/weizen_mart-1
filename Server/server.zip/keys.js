module.exports = {
  MONGOURL:
    "mongodb+srv://donaanna:dona@cluster0.zgxmytq.mongodb.net/?retryWrites=true&w=majority",
  JWT_SECRET: "hexa65ttwtintada",
  RAZORPAY_API_KEY:"rzp_test_OdmzAm3zdNv1Dn",
  RAZORYPAY_API_SECRET:"sA6uda845EdF0wOzJjbfWoYs"
};
