module.exports = {
  MONGOURL:
    "mongodb+srv://donaanna:dona@cluster0.zgxmytq.mongodb.net/?retryWrites=true&w=majority",
  JWT_SECRET: "hexa65ttwtintada",
};
